import "./style.scss";
import { List } from "./List";
import { Item } from "./Item";
import { Skeleton } from "./Skeleton";

export const PokeList = { List, Item, Skeleton };
