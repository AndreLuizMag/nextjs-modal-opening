export const Page = () => {
  return null;
};

export default Page;
