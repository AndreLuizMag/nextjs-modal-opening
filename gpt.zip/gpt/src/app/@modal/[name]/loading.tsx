const Loading = () => {
  return "Carregando Pokemon...";
};

export default Loading;
